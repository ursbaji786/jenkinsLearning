package job;

public class PrintConsole {

	public static void main(String[] args) {
		
		System.out.println("Hurray, the second Jenkins Job");

	}

}
